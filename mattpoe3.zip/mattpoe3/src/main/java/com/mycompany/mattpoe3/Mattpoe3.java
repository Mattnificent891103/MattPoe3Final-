/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
/*
 * MattPOE3 - Complete QuickChat Messaging System
 * Part 1: User Registration and Login
 * Part 2: Messaging System with QuickChat
 * Part 3: Message Manager with Arrays and Reports
 * 
 * Enhanced with Claude (Anthropic) assistance for:
 */
package com.mycompany.mattpoe3;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import javax.swing.JOptionPane;
/**
 *
 * @author dell'
 */
public class Mattpoe3 {
    
    // Registered user info
    static String registeredUsername;
    static String registeredPassword;
    static String registeredPhone;
 
    // Message counters
    static int totalMessagesSent = 0;
    static int messageNumber = 0;
 
    // === Message Data Storage Arrays (Part 3 Requirement) ===
    static ArrayList<String> sentMessages = new ArrayList<>();
    static ArrayList<String> disregardedMessages = new ArrayList<>();
    static ArrayList<String> storedMessages = new ArrayList<>();
    static ArrayList<String> recipients = new ArrayList<>();
    static ArrayList<String> senders = new ArrayList<>();  // ADDED: Sender tracking
    static ArrayList<String> messageIDs = new ArrayList<>();
    static ArrayList<String> messageHashes = new ArrayList<>();
    
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat!");
        registerUser();
 
        if (loginUser()) {
            JOptionPane.showMessageDialog(null, "Login successful. Redirecting to QuickChat...");
            
            // Load stored messages from JSON file
            readMessagesFromJSON();
            
            runMainMenu();
        } else {
            JOptionPane.showMessageDialog(null, "Login failed. Exiting app.");
        }
    }
 
    public static void registerUser() {
        boolean valid = false;
        while (!valid) {
            registeredUsername = JOptionPane.showInputDialog("Create a username (must contain _ and max 5 chars):");
            if (!(registeredUsername != null && registeredUsername.contains("_") && registeredUsername.length() <= 5)) {
                JOptionPane.showMessageDialog(null, "Invalid username.");
                continue;
            }
            registeredPassword = JOptionPane.showInputDialog("Create password (8+ chars, 1 capital, 1 number, 1 special):");
            if (!(registeredPassword != null && registeredPassword.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$"))) {
                JOptionPane.showMessageDialog(null, "Invalid password.");
                continue;
            }
            registeredPhone = JOptionPane.showInputDialog("Enter phone number (+27xxxxxxxxx):");
            if (!(registeredPhone != null && registeredPhone.matches("^\\+27[6-8]\\d{8}$"))) {
                JOptionPane.showMessageDialog(null, "Invalid phone number.");
                continue;
            }
            JOptionPane.showMessageDialog(null, "Registration successful!");
            valid = true;
        }
    }
 
    public static boolean loginUser() {
        String user = JOptionPane.showInputDialog("Login - Enter your username:");
        String pass = JOptionPane.showInputDialog("Enter your password:");
        return user != null && pass != null && user.equals(registeredUsername) && pass.equals(registeredPassword);
    }
 
    // Main menu with all features
    public static void runMainMenu() {
        boolean keepRunning = true;
 
        while (keepRunning) {
            String[] options = {
                "Send Messages",
                "Message Manager",
                "Load Test Data",  // ADDED: For testing
                "Quit"
            };
            int choice = JOptionPane.showOptionDialog(null, "Choose an option:", "Main Menu",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
 
            switch (choice) {
                case 0 -> sendMessages();
                case 1 -> messageManagerMenu();
                case 2 -> {
                    populateTestData();
                    JOptionPane.showMessageDialog(null, "Test data loaded successfully!");
                }
                case 3, JOptionPane.CLOSED_OPTION -> {
                    keepRunning = false;
                    JOptionPane.showMessageDialog(null, "Goodbye!");
                }
                default -> JOptionPane.showMessageDialog(null, "Invalid choice.");
            }
        }
    }
 
    // Send messages interface with array population
    public static void sendMessages() {
        String inputCount = JOptionPane.showInputDialog("How many messages would you like to send?");
        if (inputCount == null) return;
        int count;
        try {
            count = Integer.parseInt(inputCount);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid number.");
            return;
        }
 
        for (int i = 0; i < count; i++) {
            messageNumber++;
            String messageID = generateMessageID();
 
            String recipient = JOptionPane.showInputDialog("Enter recipient number (+27xxxxxxxxx):");
            if (recipient == null || !recipient.matches("^\\+27\\d{9}$")) {
                JOptionPane.showMessageDialog(null, "Invalid number format.");
                i--;
                messageNumber--;
                continue;
            }
 
            String message = JOptionPane.showInputDialog("Enter message (max 250 characters):");
            if (message == null) {
                i--;
                messageNumber--;
                continue;
            }
            if (message.length() > 250) {
                JOptionPane.showMessageDialog(null, "Message too long by " + (message.length() - 250) + " characters.");
                i--;
                messageNumber--;
                continue;
            }
 
            String hash = generateMessageHash(messageID, messageNumber, message);
 
            String[] actions = {"Send", "Disregard", "Store"};
            int action = JOptionPane.showOptionDialog(null, "What do you want to do with this message?", "Message Options",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, actions, actions[0]);
 
            switch (action) {
                case 0 -> {
                    // SEND: Add to sent message arrays
                    totalMessagesSent++;
                    sentMessages.add(message);
                    recipients.add(recipient);
                    senders.add(registeredUsername);  // ADDED: Track sender
                    messageIDs.add(messageID);
                    messageHashes.add(hash);
 
                    displayMessageDetails(messageID, hash, recipient, message);
                    JOptionPane.showMessageDialog(null, "Message successfully sent.");
                }
                case 1 -> {
                    // DISREGARD: Add to disregarded messages
                    disregardedMessages.add(message);
                    JOptionPane.showMessageDialog(null, "Message disregarded.");
                }
                case 2 -> {
                    // STORE: Add to stored messages and JSON
                    storedMessages.add("Recipient: " + recipient + " | Message: " + message);
                    writeMessageToJSON(messageID, hash, recipient, message);
                    JOptionPane.showMessageDialog(null, "Message stored to JSON file.");
                }
                default -> {
                    JOptionPane.showMessageDialog(null, "No action taken.");
                    i--;
                    messageNumber--;
                }
            }
        }
        JOptionPane.showMessageDialog(null, "Total messages sent this session: " + totalMessagesSent);
    }
 
    // ===================================================================
    // PART 3: MESSAGE MANAGER MENU
    // ===================================================================
    
    public static void messageManagerMenu() {
        boolean running = true;
        while (running) {
            String[] options = {
                "Display all sent messages (sender & recipient)",
                "Display longest sent message",
                "Search by Message ID",
                "Search messages by recipient",
                "Delete message by hash",
                "Show full report",
                "Back to Main Menu"
            };
            int choice = JOptionPane.showOptionDialog(null, "Message Manager Options:", "Message Manager",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
 
            switch (choice) {
                case 0 -> displaySendersAndRecipients();
                case 1 -> displayLongestMessage();
                case 2 -> {
                    String id = JOptionPane.showInputDialog("Enter Message ID:");
                    if (id != null) searchByMessageID(id);
                }
                case 3 -> {
                    String recipient = JOptionPane.showInputDialog("Enter Recipient Number:");
                    if (recipient != null) searchByRecipient(recipient);
                }
                case 4 -> {
                    String hash = JOptionPane.showInputDialog("Enter Message Hash:");
                    if (hash != null) deleteByMessageHash(hash);
                }
                case 5 -> displayReport();
                case 6, JOptionPane.CLOSED_OPTION -> running = false;
                default -> JOptionPane.showMessageDialog(null, "Invalid choice.");
            }
        }
    }
 
    // ===================================================================
    // PART 3: MESSAGE MANAGER FEATURES
    // ===================================================================
    
    /**
     * Display sender and recipient of all sent messages
     * Part 3 Requirement 2a
     */
    public static void displaySendersAndRecipients() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages to display.");
            return;
        }
        StringBuilder sb = new StringBuilder("===== SENT MESSAGES =====\n\n");
        for (int i = 0; i < sentMessages.size(); i++) {
            sb.append("Message #").append(i + 1).append("\n");
            sb.append("Sender: ").append(senders.get(i)).append("\n");
            sb.append("Recipient: ").append(recipients.get(i)).append("\n");
            sb.append("Message: ").append(sentMessages.get(i)).append("\n");
            sb.append("Hash: ").append(messageHashes.get(i)).append("\n");
            sb.append("ID: ").append(messageIDs.get(i)).append("\n");
            sb.append("---------------------------\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString(), "Sent Messages", JOptionPane.INFORMATION_MESSAGE);
    }
 
    /**
     * Display the longest sent message
     * Part 3 Requirement 2b
     */
    public static void displayLongestMessage() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages.");
            return;
        }
        String longest = "";
        int longestIndex = 0;
        for (int i = 0; i < sentMessages.size(); i++) {
            if (sentMessages.get(i).length() > longest.length()) {
                longest = sentMessages.get(i);
                longestIndex = i;
            }
        }
        
        String details = "Longest Sent Message:\n\n" +
                        "Sender: " + senders.get(longestIndex) + "\n" +
                        "Recipient: " + recipients.get(longestIndex) + "\n" +
                        "Length: " + longest.length() + " characters\n\n" +
                        "Message:\n" + longest;
        
        JOptionPane.showMessageDialog(null, details, "Longest Message", JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**
     * Helper method to find longest message (for unit tests)
     */
    public static String findLongestMessage() {
        String longest = "";
        for (String msg : sentMessages) {
            if (msg.length() > longest.length()) {
                longest = msg;
            }
        }
        return longest;
    }
 
    /**
     * Search for message by ID and display recipient and message
     * Part 3 Requirement 2c
     */
    public static void searchByMessageID(String id) {
        for (int i = 0; i < messageIDs.size(); i++) {
            if (messageIDs.get(i).equals(id)) {
                String msgDetails = "=== MESSAGE FOUND ===\n\n" +
                                   "Message ID: " + id + "\n" +
                                   "Sender: " + senders.get(i) + "\n" +
                                   "Recipient: " + recipients.get(i) + "\n" +
                                   "Message: " + sentMessages.get(i) + "\n" +
                                   "Hash: " + messageHashes.get(i);
                JOptionPane.showMessageDialog(null, msgDetails, "Search Result", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message ID not found.");
    }
    
    /**
     * Helper method for unit tests - returns recipient for message ID
     */
    public static String searchByMessageIDTest(String id) {
        for (int i = 0; i < messageIDs.size(); i++) {
            if (messageIDs.get(i).equals(id)) {
                return recipients.get(i);
            }
        }
        return null;
    }
 
    /**
     * Search all messages sent to a particular recipient
     * Part 3 Requirement 2d
     */
    public static void searchByRecipient(String recipientNumber) {
        StringBuilder sb = new StringBuilder("Messages to " + recipientNumber + ":\n\n");
        boolean found = false;
        
        // Search sent messages
        for (int i = 0; i < recipients.size(); i++) {
            if (recipients.get(i).equals(recipientNumber)) {
                sb.append("SENT: ").append(sentMessages.get(i)).append("\n");
                sb.append("  Hash: ").append(messageHashes.get(i)).append("\n\n");
                found = true;
            }
        }
        
        // Search stored messages
        for (String stored : storedMessages) {
            if (stored.contains(recipientNumber)) {
                sb.append("STORED: ").append(stored).append("\n\n");
                found = true;
            }
        }
        
        if (!found) {
            JOptionPane.showMessageDialog(null, "No messages found for recipient: " + recipientNumber);
        } else {
            JOptionPane.showMessageDialog(null, sb.toString(), "Messages by Recipient", JOptionPane.INFORMATION_MESSAGE);
        }
    }
 
    /**
     * Delete a message using the message hash
     * Part 3 Requirement 2e
     */
    public static void deleteByMessageHash(String hash) {
        for (int i = 0; i < messageHashes.size(); i++) {
            if (messageHashes.get(i).equals(hash)) {
                String msg = sentMessages.get(i);
                String recipient = recipients.get(i);
                
                // Remove from all arrays
                sentMessages.remove(i);
                recipients.remove(i);
                senders.remove(i);
                messageIDs.remove(i);
                messageHashes.remove(i);
                
                JOptionPane.showMessageDialog(null, 
                    "Message successfully deleted:\n\n" +
                    "Recipient: " + recipient + "\n" +
                    "Message: " + msg,
                    "Deletion Successful", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message hash not found.");
    }
 
    /**
     * Display full report of all sent messages
     * Part 3 Requirement 2f
     */
    public static void displayReport() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages to report.");
            return;
        }
        StringBuilder sb = new StringBuilder("========================================\n");
        sb.append("     SENT MESSAGE REPORT\n");
        sb.append("========================================\n\n");
        
        for (int i = 0; i < sentMessages.size(); i++) {
            sb.append("Message #").append(i + 1).append("\n");
            sb.append("Message Hash: ").append(messageHashes.get(i)).append("\n");
            sb.append("Recipient: ").append(recipients.get(i)).append("\n");
            sb.append("Message: ").append(sentMessages.get(i)).append("\n");
            sb.append("Message ID: ").append(messageIDs.get(i)).append("\n");
            sb.append("Sender: ").append(senders.get(i)).append("\n");
            sb.append("-----------------------------\n");
        }
        
        sb.append("\nTotal Sent Messages: ").append(sentMessages.size());
        
        JOptionPane.showMessageDialog(null, sb.toString(), "Message Report", JOptionPane.INFORMATION_MESSAGE);
    }
 
    // ===================================================================
    // PART 3: TEST DATA POPULATION
    // ===================================================================
    
    /**
     * Populate arrays with test data from Part 3 requirements
     * Test Data Messages 1-5
     */
    public static void populateTestData() {
        // Clear existing data
        sentMessages.clear();
        disregardedMessages.clear();
        storedMessages.clear();
        recipients.clear();
        senders.clear();
        messageIDs.clear();
        messageHashes.clear();
        
        // Message 1: Sent
        String msg1 = "Did you get the cake?";
        String id1 = "1234567890";
        String hash1 = generateMessageHash(id1, 0, msg1);
        sentMessages.add(msg1);
        recipients.add("+27834557896");
        senders.add("Developer");
        messageIDs.add(id1);
        messageHashes.add(hash1);
        
        // Message 2: Stored
        storedMessages.add("Recipient: +27838884567 | Message: Where are you? You are late! I have asked you to be on time.");
        
        // Message 3: Disregard
        disregardedMessages.add("Yohoooo, I am at your gate.");
        
        // Message 4: Sent
        String msg4 = "It is dinner time !";
        String id4 = "0838884567";
        String hash4 = generateMessageHash(id4, 1, msg4);
        sentMessages.add(msg4);
        recipients.add("0838884567");
        senders.add("Developer");
        messageIDs.add(id4);
        messageHashes.add(hash4);
        
        // Message 5: Stored
        storedMessages.add("Recipient: +27838884567 | Message: Ok, I am leaving without you.");
    }
 
    // ===================================================================
    // PART 3: JSON FILE READING (Claude Assisted)
    // ===================================================================
    
    /**
     * Read stored messages from JSON file into array
     * Claude (Anthropic) assisted with JSON parsing logic
     */
    public static void readMessagesFromJSON() {
        try {
            File file = new File("Jsonnew.json");
            if (!file.exists()) {
                return; // No file yet, that's okay
            }
            
            Scanner scanner = new Scanner(file);
            StringBuilder content = new StringBuilder();
            
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                
                // Simple JSON parsing - look for key fields
                if (line.startsWith("\"Recipient\":")) {
                    String recipient = extractValue(line);
                    String message = "";
                    
                    // Read next line for message
                    if (scanner.hasNextLine()) {
                        String msgLine = scanner.nextLine().trim();
                        if (msgLine.startsWith("\"Message\":")) {
                            message = extractValue(msgLine);
                        }
                    }
                    
                    if (!recipient.isEmpty() && !message.isEmpty()) {
                        storedMessages.add("Recipient: " + recipient + " | Message: " + message);
                    }
                }
            }
            scanner.close();
            
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading JSON file: " + e.getMessage());
        }
    }
    
    /**
     * Helper method to extract value from JSON line
     * Claude assisted
     */
    private static String extractValue(String line) {
        int start = line.indexOf("\"") + 1;
        start = line.indexOf("\"", start) + 1;
        int end = line.lastIndexOf("\"");
        if (start > 0 && end > start) {
            return line.substring(start, end);
        }
        return "";
    }
 
    // ===================================================================
    // HELPER METHODS
    // ===================================================================
    
    public static String generateMessageID() {
        return String.format("%010d", new Random().nextInt(1_000_000_000));
    }
 
    public static String generateMessageHash(String id, int num, String msg) {
        String[] words = msg.trim().split("\\s+");
        String first = words.length > 0 ? words[0].replaceAll("[^a-zA-Z]", "") : "";
        String last = words.length > 1 ? words[words.length - 1].replaceAll("[^a-zA-Z]", "") : first;
        return (id.substring(0, 2) + ":" + num + ":" + first + last).toUpperCase();
    }
 
    public static void displayMessageDetails(String id, String hash, String recipient, String message) {
        JOptionPane.showMessageDialog(null,
                "Message ID: " + id +
                        "\nHash: " + hash +
                        "\nRecipient: " + recipient +
                        "\nMessage: " + message);
    }
 
    public static void writeMessageToJSON(String messageID, String hash, String recipient, String message) {
        StringBuilder jsonEntry = new StringBuilder();
        jsonEntry.append("{\n");
        jsonEntry.append("  \"MessageID\": \"").append(messageID).append("\",\n");
        jsonEntry.append("  \"MessageHash\": \"").append(hash).append("\",\n");
        jsonEntry.append("  \"Recipient\": \"").append(recipient).append("\",\n");
        jsonEntry.append("  \"Message\": \"").append(message.replace("\"", "\\\"")).append("\"\n");
        jsonEntry.append("},\n");
 
        try (FileWriter file = new FileWriter("Jsonnew.json", true)) {
            file.write(jsonEntry.toString());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing JSON file: " + e.getMessage());
        }
    }
}






