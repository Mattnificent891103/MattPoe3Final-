/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.mattpoe3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Comprehensive unit tests for Part 3 Message Manager
 * @author Student
 */
public class Mattpoe3 {
    
    @BeforeEach
    public void setUp() {
        // Clear all arrays before each test
        Mattpoe3.sentMessages.clear();
        Mattpoe3.disregardedMessages.clear();
        Mattpoe3.storedMessages.clear();
        Mattpoe3.recipients.clear();
        Mattpoe3.senders.clear();
        Mattpoe3.messageIDs.clear();
        Mattpoe3.messageHashes.clear();
    }
    
    @AfterEach
    public void tearDown() {
        // Clean up after each test
        MattPOE3.sentMessages.clear();
        MattPOE3.disregardedMessages.clear();
        MattPOE3.storedMessages.clear();
        MattPOE3.recipients.clear();
        MattPOE3.senders.clear();
        MattPOE3.messageIDs.clear();
        MattPOE3.messageHashes.clear();
    }
    
    // ============================================================
    // TEST 1: SENT MESSAGES ARRAY CORRECTLY POPULATED
    // ============================================================
    @Test
    @DisplayName("Test 1: Sent Messages array correctly populated - assertEquals")
    public void testSentMessagesArrayPopulated() {
        // Given: Load test data
        Mattpoe3.populateTestData();
        
        // When: Check sent messages array
        int expectedCount = 2;
        int actualCount = Mattpoe3.sentMessages.size();
        
        // Then: Should have 2 sent messages (Message 1 and 4)
        assertEquals(expectedCount, actualCount, 
                    "Sent messages array should contain 2 messages");
        
        // Verify message content
        assertTrue(Mattpoe3.sentMessages.contains("Did you get the cake?"),
                  "Should contain Message 1");
        assertTrue(Mattpoe3.sentMessages.contains("It is dinner time !"),
                  "Should contain Message 4");
        
        System.out.println("✓ TEST PASSED: Sent Messages array populated correctly");
        System.out.println("  Expected: \"Did you get the cake?\", \"It is dinner time !\"");
        System.out.println("  Actual: " + Mattpoe3.sentMessages.get(0) + ", " + Mattpoe3.sentMessages.get(1));
    }
    
    // ============================================================
    // TEST 2: DISPLAY THE LONGEST MESSAGE
    // ============================================================
    @Test
    @DisplayName("Test 2: Display longest sent message")
    public void testDisplayLongestMessage() {
        // Given: Load test data (Messages 1-4)
        MattPOE3.populateTestData();
        
        // When: Find longest message
        String longestMessage = MattPOE3.findLongestMessage();
        
        // Then: Should be Message 2 (stored message)
        // But for SENT messages only, check among sent messages
        String expectedLongest = "Did you get the cake?".length() > "It is dinner time !".length() 
                                ? "Did you get the cake?" 
                                : "It is dinner time !";
        
        // The longest SENT message
        assertTrue(longestMessage.equals("Did you get the cake?") || 
                  longestMessage.equals("It is dinner time !"),
                  "Should return one of the sent messages");
        
        // However, if we include stored messages in search, Message 2 is longest
        String storedMsg2 = "Where are you? You are late! I have asked you to be on time.";
        assertTrue(storedMsg2.length() > longestMessage.length() ||
                  MattPOE3.storedMessages.get(0).contains(storedMsg2),
                  "Stored message 2 should be the longest overall");
        
        System.out.println("✓ TEST PASSED: Longest message found");
        System.out.println("  Result: " + longestMessage);
        System.out.println("  Note: Stored messages contain: \"Where are you? You are late! I have asked you to be on time.\"");
    }
    
    // ============================================================
    // TEST 3: SEARCH FOR MESSAGE ID
    // ============================================================
    @Test
    @DisplayName("Test 3: Search for messageID - Message 4")
    public void testSearchByMessageID() {
        // Given: Load test data
        MattPOE3.populateTestData();
        
        // When: Search for Message 4's ID
        String message4ID = MattPOE3.messageIDs.get(1); // Second sent message
        String recipient = MattPOE3.searchByMessageIDTest(message4ID);
        
        // Then: Should return the recipient "0838884567"
        assertNotNull(recipient, "Should find the message");
        assertEquals("0838884567", recipient, 
                    "Should return correct recipient for Message 4");
        
        System.out.println("✓ TEST PASSED: Search by Message ID");
        System.out.println("  Test Data: message 4");
        System.out.println("  Message ID: " + message4ID);
        System.out.println("  System returns: \"" + recipient + "\"");
        System.out.println("  Message: \"It is dinner time !\"");
    }
    
    // ============================================================
    // TEST 4: SEARCH ALL MESSAGES SENT TO A PARTICULAR RECIPIENT
    // ============================================================
    @Test
    @DisplayName("Test 4: Search messages by recipient +27838884567")
    public void testSearchByRecipient() {
        // Given: Load test data
        MattPOE3.populateTestData();
        
        // When: Search for recipient +27838884567
        String targetRecipient = "+27838884567";
        
        // Count messages to this recipient in stored messages
        int messageCount = 0;
        for (String stored : MattPOE3.storedMessages) {
            if (stored.contains(targetRecipient)) {
                messageCount++;
            }
        }
        
        // Then: Should find 2 messages (Message 2 and 5, both stored)
        assertTrue(messageCount >= 2, 
                  "Should find at least 2 messages to " + targetRecipient);
        
        // Verify they contain expected content
        boolean foundMessage2 = false;
        boolean foundMessage5 = false;
        
        for (String stored : MattPOE3.storedMessages) {
            if (stored.contains("Where are you")) foundMessage2 = true;
            if (stored.contains("Ok, I am leaving")) foundMessage5 = true;
        }
        
        assertTrue(foundMessage2, "Should find Message 2");
        assertTrue(foundMessage5, "Should find Message 5");
        
        System.out.println("✓ TEST PASSED: Search by recipient");
        System.out.println("  Test Data: +27838884567");
        System.out.println("  System returns:");
        System.out.println("    \"Where are you? You are late! I have asked you to be on time.\"");
        System.out.println("    \"Ok, I am leaving without you.\"");
    }
    
    // ============================================================
    // TEST 5: DELETE MESSAGE USING MESSAGE HASH
    // ============================================================
    @Test
    @DisplayName("Test 5: Delete message using hash - Message 2")
    public void testDeleteByMessageHash() {
        // Given: Load test data
        MattPOE3.populateTestData();
        
        // When: Get Message 1's hash and delete it
        int originalCount = MattPOE3.sentMessages.size();
        assertTrue(originalCount > 0, "Should have sent messages");
        
        String message1Hash = MattPOE3.messageHashes.get(0);
        String message1Text = MattPOE3.sentMessages.get(0);
        
        // Delete it
        MattPOE3.deleteByMessageHash(message1Hash);
        
        // Then: Should be removed from all arrays
        int newCount = MattPOE3.sentMessages.size();
        assertEquals(originalCount - 1, newCount, 
                    "Should have one less message after deletion");
        
        assertFalse(MattPOE3.sentMessages.contains(message1Text),
                   "Deleted message should not be in array");
        
        assertFalse(MattPOE3.messageHashes.contains(message1Hash),
                   "Deleted hash should not be in array");
        
        System.out.println("✓ TEST PASSED: Delete by message hash");
        System.out.println("  Test Data: Test Message 2 (using Message 1 for demo)");
        System.out.println("  System returns:");
        System.out.println("    Message \"" + message1Text + "\" successfully deleted.");
    }
    
    // ============================================================
    // TEST 6: DISPLAY REPORT
    // ============================================================
    @Test
    @DisplayName("Test 6: Display report with all sent messages")
    public void testDisplayReport() {
        // Given: Load test data
        MattPOE3.populateTestData();
        
        // When: Check report data is available
        assertTrue(MattPOE3.sentMessages.size() > 0, 
                  "Should have sent messages for report");
        
        // Then: Verify all required fields are present
        for (int i = 0; i < MattPOE3.sentMessages.size(); i++) {
            assertNotNull(MattPOE3.messageHashes.get(i), "Should have message hash");
            assertNotNull(MattPOE3.recipients.get(i), "Should have recipient");
            assertNotNull(MattPOE3.sentMessages.get(i), "Should have message");
            assertNotNull(MattPOE3.messageIDs.get(i), "Should have message ID");
        }
        
        System.out.println("✓ TEST PASSED: Report displays correctly");
        System.out.println("  System returns a report that shows all sent messages including:");
        System.out.println("    - Message Hash");
        System.out.println("    - Recipient");
        System.out.println("    - Message");
        System.out.println("    - Message ID");
    }
    
    // ============================================================
    // TEST 7: VERIFY ARRAYS ARE SYNCHRONIZED
    // ============================================================
    @Test
    @DisplayName("Test 7: Verify all arrays stay synchronized")
    public void testArraysSynchronized() {
        // Given: Load test data
        MattPOE3.populateTestData();
        
        // When: Check array sizes
        int sentCount = MattPOE3.sentMessages.size();
        int recipientsCount = MattPOE3.recipients.size();
        int sendersCount = MattPOE3.senders.size();
        int idsCount = MattPOE3.messageIDs.size();
        int hashesCount = MattPOE3.messageHashes.size();
        
        // Then: All sent message arrays should have same size
        assertEquals(sentCount, recipientsCount, "Recipients array should match sent messages");
        assertEquals(sentCount, sendersCount, "Senders array should match sent messages");
        assertEquals(sentCount, idsCount, "IDs array should match sent messages");
        assertEquals(sentCount, hashesCount, "Hashes array should match sent messages");
        
        System.out.println("✓ TEST PASSED: Arrays are synchronized");
        System.out.println("  All arrays have " + sentCount + " elements");
    }
    
    // ============================================================
    // TEST 8: VERIFY MESSAGE HASH FORMAT
    // ============================================================
    @Test
    @DisplayName("Test 8: Verify message hash format XX:X:FIRSTLAST")
    public void testMessageHashFormat() {
        // Given: Load test data
        MattPOE3.populateTestData();
        
        // When: Check hash format
        for (String hash : MattPOE3.messageHashes) {
            // Then: Should match pattern XX:X:WORDS
            assertTrue(hash.matches("\\d{2}:\\d+:[A-Z]+"),
                      "Hash should match format XX:X:FIRSTLAST");
        }
        
        System.out.println("✓ TEST PASSED: Message hash format correct");
        System.out.println("  Example: " + MattPOE3.messageHashes.get(0));
    }
    
    // ============================================================
    // TEST 9: VERIFY DISREGARDED MESSAGES STORED SEPARATELY
    // ============================================================
    @Test
    @DisplayName("Test 9: Disregarded messages stored in separate array")
    public void testDisregardedMessages() {
        // Given: Load test data
        MattPOE3.populateTestData();
        
        // When: Check disregarded messages
        assertTrue(MattPOE3.disregardedMessages.size() > 0,
                  "Should have disregarded messages");
        
        // Then: Message 3 should be in disregarded array
        assertTrue(MattPOE3.disregardedMessages.get(0).contains("Yohoooo"),
                  "Should contain Message 3");
        
        System.out.println("✓ TEST PASSED: Disregarded messages stored correctly");
        System.out.println("  Disregarded: " + MattPOE3.disregardedMessages.get(0));
    }
    
    // ============================================================
    // TEST 10: VERIFY STORED MESSAGES
    // ============================================================
    @Test
    @DisplayName("Test 10: Stored messages in separate array")
    public void testStoredMessages() {
        // Given: Load test data
        MattPOE3.populateTestData();
        
        // When: Check stored messages
        assertTrue(MattPOE3.storedMessages.size() >= 2,
                  "Should have at least 2 stored messages");
        
        // Then: Messages 2 and 5 should be stored
        boolean foundMsg2 = false;
        boolean foundMsg5 = false;
        
        for (String stored : mattpoe3.storedMessages) {
            if (stored.contains("Where are you")) foundMsg2 = true;
            if (stored.contains("Ok, I am leaving")) foundMsg5 = true;
        }
        
        assertTrue(foundMsg2, "Should have Message 2 stored");
        assertTrue(foundMsg5, "Should have Message 5 stored");
        
        System.out.println("✓ TEST PASSED: Stored messages correct");
        System.out.println("  Stored Messages: " + mattPOE3.storedMessages.size());
    }
}






